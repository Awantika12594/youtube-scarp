# BlueStacks - YouTube Scraper

This app fetches the YouTube trending videos and adds them in the MySQL database. Technologies used are:

  - API Development - Node.js, Express.js
  - Webpages - Server-side - PHP
  - Webpages - Client-side - HTML5, CSS3
  - Libraries - YouTube Data API - Node.js based, BootStrap, DataTable.

# Features!

  - Fetches the trending videos from YouTube India region.
  - Users can visit the home page and view the list of 50 trending videos inside DataTable.
  
![alt text](https://i.imgur.com/iKU72n3.png)

- On click of the view button, the user is redirected to a different page where all the information related to the video is displayed. Also, the video automatically starts playing after the page is loaded.

![alt text](https://i.imgur.com/WgQpS69.png)

- Users can also update the trending video link by clicking the "Click here to update list" button present in the home page.

![alt text](https://i.imgur.com/qwYhQe1.png)

 - If the video is alread present the database, then we are updating the video information. For example, latest view counts, likes, dislikes and all other information related to video gets updated if the video is already present in the database. If not, then new entry for the video is created.

## Folder and files structure:
 - youtube-trending-scraper
    - frontend
        - index.php
        - single-video.php
    - package.json
    - client_secret.json
    - youtube-scraper.js
    - index.js

## Approach used for implementing this app:
1. Started with creating the package.json file with all the required information about the app.
2. Followed YouTube's data API tutorial to create project and add app for authorization from gmail account. Ref: https://developers.google.com/youtube/v3/quickstart/nodejs
    ```    
    "google-auth-library": "^6.1.3",
    "googleapis": "^63.0.0",
    ```
3. Once the authorization was done, focused on fetching the data of trending videos. 
4. Once the data started recieving, focused on saving the data in DB (MySQL).
5. Used `"mysql": "^2.18.1",` package to make connection and any operation on MySQL database.
6. Data started to save in DB. Faced issue of query error due to not escaped title and description of the videos. To resolve this issue used `"sqlstring": "^2.3.2"` which converts the string to be saved properly in MySQL.
7. Started working on creating the API using Node.js. I never created my own API before, so this was very exciting for me. Looked for many libraries and found express.js using which I created the API points for the app.
8. Following were the API points I created:
     -  Fetch all videos.
         Pattern - http://localhost:3000/api/videos.
     -  Fetch single video.
         Pattern - http://localhost:3000/api/videos/mwhmwrPaphY.
     -  Fetch updated trending videos list.
         Pattern - http://localhost:3000/api/updatevideos.
9. I first made sure that the API points were working properly before using them by hitting them from Postman and trying opening them in browser.
- All trending videos:
![alt text](https://i.imgur.com/zR5E0cT.png)
- Single video information:
![alt text](https://i.imgur.com/K4RpOm9.png)
- Updated/Insert new videos in the list:
![alt text](https://i.imgur.com/M9Qe7hw.png)
10. Once the endpoints were working properly, I started working on the frontend of the app. Created index.php file and by default fetched trending videos from the endpoint I created earlier.
11. Added DataTable to the list for better user experience.
12. Added form and button to redirect user to a different to view single video details.
13. Created new file called single-video.php to display all the information related the video which was clicked. 
![alt text](https://i.imgur.com/CuUCuy4.png)
14. This was again using the endpoint I created to fetch a single video information by passing the YouTube ID to it.
15. Next, I started working on the button on home page to fetch the latest list and update the videos if they were already present.
16. For this, I already had a endpoint using which I was fetching thew new list. I put each video in the loop and checked in the database id the YouTube Id was present or not. If yes, then ran update command and if not, then ran insert command.
17. This button now started fetching the latest details and updating the database which was indirectly updating the information on home page as well.
18. Now, it was time to make this project live. I already had a GoDaddy domain and hosting.
19. I found some articles on how to host node.js on GoDaddy server. Once of them was very helpful. I turned on the SSH and logged in using putty. Added Node file inside bin folder. Ran the `node app.js` command to test it with sample `app.js` file and after some debugging and minor fixes, the file started working on the server using SSH.
20. Now, It was time for me to add my API ednpoints to GoDaddy server. I followed the same steps. File started running but for some reason I was facing issue with the port. I kept it at 3000 but still it was not working. I tried many possible ways but sadly, couldn't find the solution to it.
21. After some time, the started server was automatically shutting down due to some unknown error.
![alt text](https://i.imgur.com/AGJirmZ.png)
22. So, now the whole thing was working on localhost but not on the server.
23. I'm attaching the link to the screencast of my localhost of all the functionalities. Please check this link: 

https://www.dropbox.com/s/7nvms48v3xo1l33/gxAijG6BLZ.mp4?dl=0