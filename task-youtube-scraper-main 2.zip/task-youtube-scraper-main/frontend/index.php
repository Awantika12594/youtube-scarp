<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Youtube Videos :- Trending</title>
        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css"/>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <style>
            /* Trending videos heading CSS */
            .trending-videos-heading {
                font-size: 32px;
            }
            /* Add space between rows CSS */
            .trending-videos-container .row {
                margin-top: 20px;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
    <div class="container trending-videos-container">
        <div class="row">
            <ul class="list-group col-lg-12 col-md-12 col-sm-12">
                <li class="list-group-item list-group-item-dark"><h1 class="display-4 trending-videos-heading">YouTube Trending Videos</h1></li>
            </ul>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <form method="post">
                    <input type="submit" class="btn btn-dark" name="btn-update-trending-list" value="Click here to update list" />
                </form>
            </div>
        </div>
<?php

// API URL to fetch the videos - updatevideos if update requested else videos.
$api_url = isset( $_POST['btn-update-trending-list'] ) ? 'http://localhost:3000/api/updatevideos' : 'http://localhost:3000/api/videos';

// Read JSON file.
$json_data = file_get_contents($api_url);

// Decode JSON data into PHP array.
$response_data = json_decode($json_data);

// All videos data exists in 'response_data' object.
if ( 200 === $response_data->status && !empty( $response_data->response ) ) { ?>
    <table id="userTable" class="display compact">
        <thead>
            <th>Video ID</th>
            <th>Video Title</th>
            <th>No. of Views</th>
            <th>View Video</th>
        </thead>
        <tbody>
            <?php foreach($response_data->response as $video) { ?>
                <tr>
                    <td><?php echo $video->id; ?></td>
                    <td><?php echo $video->title; ?></td>
                    <td><?php echo $video->view_count; ?></td>
                    <td>
                        <form method="get" action="single-video.php">
                            <input type="hidden" id="video-id" name="yt-id" value="<?php echo $video->yt_id; ?>" />
                            <input type="submit" id="btn-view-single-video" name="btn-view-single-video" value="View" />
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
<?php } ?>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script type="text/javascript" src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
        <script>
        $(document).ready(function() {
            $('#userTable').DataTable();
        });
        </script>
        </div>
    </body>
</html>