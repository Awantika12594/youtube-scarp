<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Video Details</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <style>
            /* Add space between rows CSS */
            .single-video-container .row {
                margin-top: 20px;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
<?php

/**
 * Return from here if the required parameters are not set.
 */
if ( ! isset( $_GET['btn-view-single-video'] ) || 'View' !== $_GET['btn-view-single-video'] || ! isset( $_GET['yt-id'] ) ) {
    return;
}

// Get YouTube video ID.
$yt_id = $_GET['yt-id'];

// API URL to fetch the single video information.
$api_url = 'http://localhost:3000/api/videos/' . $yt_id;

// Read JSON file.
$json_data = file_get_contents($api_url);

// Decode JSON data into PHP array.
$response_data = json_decode($json_data);

// All user data exists in 'response_data' object.
if ( 200 === $response_data->status && !empty( $response_data->response ) ) { ?>
<?php   $video = $response_data->response[0]; ?>
    <div class="container text-center single-video-container">
        <div class="row">
            <ul class="list-group col-lg-12 col-md-12 col-sm-12">
                <li class="list-group-item list-group-item-dark"><b><?php echo $video->title; ?></b></li>
            </ul>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <iframe width="640" height="380" src="https://www.youtube.com/embed/<?php echo $yt_id; ?>?autoplay=1&mute=1"></iframe>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
                <button type="button" class="btn btn-info">
                VIEWS <span class="badge badge-light"><?php echo $video->view_count; ?></span>
                </button>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
                <button type="button" class="btn btn-success">
                LIKES <span class="badge badge-light"><?php echo $video->likes; ?></span>
                </button>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
                <button type="button" class="btn btn-danger">
                DISLIKES <span class="badge badge-light"><?php echo $video->dislikes; ?></span>
                </button>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <h1 class="display-4">Video Description</h1>
                <p class="text-justify"><?php echo $video->description; ?></p>
            </div>
        </div>
    </div>
<?php } ?>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    </body>
</html>